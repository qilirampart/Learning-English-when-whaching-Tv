<template>
  <nav class="sticky top-0 z-50 bg-white/70 backdrop-blur-xl border-b border-white/50">
    <div class="w-full">
      <div class="max-w-[1600px] mx-auto px-8 sm:px-12 lg:px-16">
        <div class="flex justify-between items-center h-20 gap-8">
        <!-- Logo -->
        <div class="flex items-center gap-3 min-w-[140px]">
          <div class="w-10 h-10 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
            </svg>
          </div>
          <span class="hidden sm:block font-bold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700">单词助手</span>
        </div>

        <!-- Navigation Links -->
        <div class="hidden lg:flex gap-1 items-center bg-slate-100/50 px-2 py-2 rounded-full border border-slate-200/50 backdrop-blur-sm">
          <router-link
            to="/"
            :class="isActive('/')
              ? 'bg-white text-slate-900 shadow-sm px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap'
              : 'text-slate-500 hover:text-slate-900 px-5 py-2 text-sm font-medium transition-colors whitespace-nowrap'"
          >
            首页
          </router-link>
          <router-link
            to="/query"
            :class="isActive('/query')
              ? 'bg-white text-slate-900 shadow-sm px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap'
              : 'text-slate-500 hover:text-slate-900 px-5 py-2 text-sm font-medium transition-colors whitespace-nowrap'"
          >
            快速查询
          </router-link>
          <router-link
            to="/words"
            :class="isActive('/words')
              ? 'bg-white text-slate-900 shadow-sm px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap'
              : 'text-slate-500 hover:text-slate-900 px-5 py-2 text-sm font-medium transition-colors whitespace-nowrap'"
          >
            单词库
          </router-link>
          <router-link
            to="/learning"
            :class="isActive('/learning')
              ? 'bg-white text-slate-900 shadow-sm px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap'
              : 'text-slate-500 hover:text-slate-900 px-5 py-2 text-sm font-medium transition-colors whitespace-nowrap'"
          >
            学习计划
          </router-link>
          <router-link
            to="/statistics"
            :class="isActive('/statistics')
              ? 'bg-white text-slate-900 shadow-sm px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap'
              : 'text-slate-500 hover:text-slate-900 px-5 py-2 text-sm font-medium transition-colors whitespace-nowrap'"
          >
            统计
          </router-link>
          <router-link
            to="/ai-assistant"
            :class="isActive('/ai-assistant')
              ? 'bg-white text-slate-900 shadow-sm px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap'
              : 'text-slate-500 hover:text-slate-900 px-5 py-2 text-sm font-medium transition-colors whitespace-nowrap'"
          >
            AI助手
          </router-link>
        </div>

        <!-- Right Actions -->
        <div class="flex items-center gap-3 min-w-fit justify-end">
          <button
            @click="toggleTheme"
            class="p-2.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all flex-shrink-0"
          >
            <Sun v-if="themeMode === 'light'" class="w-5 h-5" />
            <Moon v-else-if="themeMode === 'dark'" class="w-5 h-5" />
            <Monitor v-else class="w-5 h-5" />
          </button>

          <div v-if="authStore.user" class="h-10 w-10 rounded-full bg-gradient-to-tr from-pink-400 to-orange-400 p-[2px] cursor-pointer hover:scale-110 transition-transform flex-shrink-0" @click="showUserMenu = !showUserMenu">
            <div class="h-full w-full rounded-full bg-white border-2 border-transparent flex items-center justify-center text-sm font-bold text-slate-700">
              {{ authStore.user.username.charAt(0).toUpperCase() }}
            </div>
          </div>

          <!-- Dropdown Menu -->
          <transition
            enter-active-class="transition ease-out duration-100"
            enter-from-class="transform opacity-0 scale-95"
            enter-to-class="transform opacity-100 scale-100"
            leave-active-class="transition ease-in duration-75"
            leave-from-class="transform opacity-100 scale-100"
            leave-to-class="transform opacity-0 scale-95"
          >
            <div
              v-if="showUserMenu"
              class="absolute right-4 top-16 w-56 bg-white/80 backdrop-blur-md rounded-2xl shadow-xl py-2 border border-white/50"
            >
              <div class="px-4 py-3 border-b border-slate-200">
                <p class="text-sm font-semibold text-slate-900">{{ authStore.user.username }}</p>
                <p class="text-xs text-slate-500 truncate">{{ authStore.user.email }}</p>
              </div>
              <button
                @click="handleLogout"
                class="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2"
              >
                <LogOut class="w-4 h-4" />
                退出登录
              </button>
            </div>
          </transition>
        </div>
        </div>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useDarkMode } from '@/utils/useDarkMode'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Sun, Moon, Monitor, LogOut } from 'lucide-vue-next'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()
const { themeMode, setThemeMode } = useDarkMode()

const showUserMenu = ref(false)

const isActive = (path) => {
  return route.path === path
}

const toggleTheme = () => {
  const modes = ['light', 'dark', 'auto']
  const currentIndex = modes.indexOf(themeMode.value)
  const nextMode = modes[(currentIndex + 1) % modes.length]
  setThemeMode(nextMode)
}

const handleLogout = async () => {
  try {
    await ElMessageBox.confirm('确定要退出登录吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })

    authStore.logout()
    ElMessage.success('已退出登录')
    router.push('/login')
  } catch {
    // 用户取消
  }
}
</script>

<style scoped>
/* Click outside to close menu */
</style>
