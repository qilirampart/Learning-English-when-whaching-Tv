<template>
  <div id="app" class="min-h-screen bg-slate-50 text-slate-800 relative overflow-x-hidden">
    <!-- Animated Mesh Gradient Background -->
    <div class="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
      <div class="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float-slow"></div>
      <div class="absolute top-[-10%] right-[20%] w-[400px] h-[400px] bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float-medium"></div>
      <div class="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float-fast"></div>
    </div>

    <!-- Auth Pages (Login/Register) -->
    <template v-if="isAuthPage">
      <router-view />
    </template>

    <!-- Main App Layout -->
    <template v-else>
      <!-- Top Navigation -->
      <TopNavigation />

      <!-- Main Content -->
      <main class="pt-20 pb-12">
        <router-view />
      </main>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import TopNavigation from '@/components/TopNavigation.vue'

const route = useRoute()
const authStore = useAuthStore()

const isAuthPage = computed(() => ['/login', '/register'].includes(route.path))

// 初始化时加载用户信息
onMounted(async () => {
  if (authStore.token && !authStore.user) {
    await authStore.initialize()
  }
})
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body, #app {
  height: 100%;
  width: 100%;
}

body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  overflow-x: hidden;
}

#app {
  position: relative;
}

/* Custom scrollbar */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: rgba(0, 0, 0, 0.05);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
}
</style>
