/**
 * 深色模式工具 - 主题切换功能
 * 支持浅色/深色/自动（跟随系统）三种模式
 */

import { ref, watch, onMounted } from 'vue'

// 主题模式枚举
export const ThemeMode = {
  LIGHT: 'light',
  DARK: 'dark',
  AUTO: 'auto',
}

// 存储键
const STORAGE_KEY = 'theme-mode'

/**
 * 深色模式组合式函数
 */
export function useDarkMode() {
  // 当前主题模式（用户选择）
  const themeMode = ref(localStorage.getItem(STORAGE_KEY) || ThemeMode.AUTO)

  // 实际应用的主题（计算后的结果）
  const isDark = ref(false)

  /**
   * 检测系统主题偏好
   */
  const getSystemTheme = () => {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return ThemeMode.DARK
    }
    return ThemeMode.LIGHT
  }

  /**
   * 应用主题到 DOM
   */
  const applyTheme = (dark) => {
    const html = document.documentElement

    if (dark) {
      html.classList.add('dark')
      html.setAttribute('data-theme', 'dark')
    } else {
      html.classList.remove('dark')
      html.setAttribute('data-theme', 'light')
    }

    isDark.value = dark
  }

  /**
   * 更新主题
   */
  const updateTheme = () => {
    let shouldBeDark = false

    switch (themeMode.value) {
      case ThemeMode.DARK:
        shouldBeDark = true
        break
      case ThemeMode.LIGHT:
        shouldBeDark = false
        break
      case ThemeMode.AUTO:
        shouldBeDark = getSystemTheme() === ThemeMode.DARK
        break
    }

    applyTheme(shouldBeDark)
  }

  /**
   * 设置主题模式
   * @param {string} mode - 'light' | 'dark' | 'auto'
   */
  const setThemeMode = (mode) => {
    if (Object.values(ThemeMode).includes(mode)) {
      themeMode.value = mode
      localStorage.setItem(STORAGE_KEY, mode)
      updateTheme()
    }
  }

  /**
   * 切换浅色/深色模式
   */
  const toggleDarkMode = () => {
    const newMode = isDark.value ? ThemeMode.LIGHT : ThemeMode.DARK
    setThemeMode(newMode)
  }

  /**
   * 监听系统主题变化
   */
  const watchSystemTheme = () => {
    if (window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')

      // 现代浏览器使用 addEventListener
      const handler = () => {
        if (themeMode.value === ThemeMode.AUTO) {
          updateTheme()
        }
      }

      try {
        mediaQuery.addEventListener('change', handler)
        return () => mediaQuery.removeEventListener('change', handler)
      } catch (e) {
        // 旧版浏览器使用 addListener
        mediaQuery.addListener(handler)
        return () => mediaQuery.removeListener(handler)
      }
    }
  }

  /**
   * 获取主题模式的显示文本
   */
  const getThemeModeText = (mode) => {
    const textMap = {
      [ThemeMode.LIGHT]: '浅色模式',
      [ThemeMode.DARK]: '深色模式',
      [ThemeMode.AUTO]: '跟随系统',
    }
    return textMap[mode] || '未知'
  }

  /**
   * 获取主题模式的图标
   */
  const getThemeModeIcon = (mode) => {
    const iconMap = {
      [ThemeMode.LIGHT]: 'Sunny',
      [ThemeMode.DARK]: 'Moon',
      [ThemeMode.AUTO]: 'Monitor',
    }
    return iconMap[mode] || 'Monitor'
  }

  // 监听主题模式变化
  watch(themeMode, updateTheme)

  return {
    // 状态
    themeMode,
    isDark,

    // 方法
    setThemeMode,
    toggleDarkMode,
    updateTheme,
    watchSystemTheme,
    getThemeModeText,
    getThemeModeIcon,
    getSystemTheme,

    // 常量
    ThemeMode,
  }
}

/**
 * 初始化深色模式
 * 在应用启动时调用
 */
export function initDarkMode() {
  const { updateTheme, watchSystemTheme } = useDarkMode()

  // 初始化主题
  updateTheme()

  // 监听系统主题变化
  const cleanup = watchSystemTheme()

  return cleanup
}

export default useDarkMode
