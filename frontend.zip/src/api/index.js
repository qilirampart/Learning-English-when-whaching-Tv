import request from '@/utils/request'

// 单词相关API
export const wordApi = {
  // 查询单词
  async query(data) {
    const response = await request.post('/api/words/query', data)
    return response.data
  },

  // 搜索单词
  async search(keyword) {
    const response = await request.get('/api/words/search', { params: { keyword } })
    return response.data
  },

  // 获取单词详情
  async getDetail(id) {
    const response = await request.get(`/api/words/${id}`)
    return response.data
  },

  // 获取单词列表
  async getList(params) {
    const response = await request.get('/api/words/list', { params })
    return response.data
  },

  // 导出单词本
  async exportWords(format = 'excel') {
    const response = await request.get('/api/words/export', {
      params: { format },
      responseType: 'blob'
    })

    // 创建下载链接
    const url = window.URL.createObjectURL(new Blob([response.data]))
    const link = document.createElement('a')
    link.href = url

    // 设置文件名
    const contentDisposition = response.headers['content-disposition']
    let filename = `单词本_${new Date().getTime()}.${format === 'pdf' ? 'pdf' : 'xlsx'}`

    if (contentDisposition) {
      const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)
      if (filenameMatch && filenameMatch[1]) {
        filename = decodeURIComponent(filenameMatch[1].replace(/['"]/g, ''))
      }
    }

    link.setAttribute('download', filename)
    document.body.appendChild(link)
    link.click()

    // 清理
    link.remove()
    window.URL.revokeObjectURL(url)
  },

  // 检查导出功能可用性
  async checkExportAvailability() {
    const response = await request.get('/api/words/export/check')
    return response.data
  }
}

// 学习计划相关API
export const learningApi = {
  // 获取今日待复习单词
  async getTodayReview() {
    const response = await request.get('/api/learning/today')
    return response.data
  },

  // 获取学习计划概览
  async getPlan() {
    const response = await request.get('/api/learning/plan')
    return response.data
  },

  // 提交复习结果
  async submitReview(data) {
    const response = await request.post('/api/learning/review', data)
    return response.data
  }
}

// 统计相关API
export const statisticsApi = {
  // 获取统计概览
  async getOverview() {
    const response = await request.get('/api/statistics/overview')
    return response.data
  },

  // 获取剧集统计
  async getTvShows() {
    const response = await request.get('/api/statistics/tv_shows')
    return response.data
  }
}

export default request

