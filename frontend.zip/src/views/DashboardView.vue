<template>
  <div class="w-full min-h-screen flex justify-center">
    <div class="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <!-- Welcome Header -->
      <div class="mb-10 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div class="space-y-1">
          <h1 class="text-4xl font-extrabold text-slate-900 leading-tight">
            �٣�{{ authStore.user?.username || 'TestUser' }} <span class="animate-pulse inline-block">?</span>
          </h1>
          <p class="text-slate-500 mt-1 text-base">׼����ͨ�� Netflix ����Ӣ������</p>
        </div>
        <button class="hidden lg:flex items-center gap-2 bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-slate-800 transition-colors shadow-lg shadow-slate-900/20">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          ��Ŀ��
        </button>
      </div>

      <!-- Bento Grid Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-4 md:gap-6 auto-rows-[minmax(180px,auto)]">
        <!-- Current Study Focus - Large Card (2x2) -->
        <div class="lg:col-span-2 lg:row-span-2 relative rounded-3xl overflow-hidden group cursor-pointer shadow-xl shadow-indigo-500/20 min-h-[420px]">
          <img src="https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=2070&auto=format&fit=crop" class="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="Cinema">
          <div class="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/70 to-transparent"></div>

          <div class="relative z-10 flex flex-col h-full justify-between p-8">
            <div class="flex justify-between items-start">
              <span class="bg-white/20 backdrop-blur-md border border-white/20 text-white text-xs font-bold px-4 py-2 rounded-full uppercase tracking-wide">�����ۿ�</span>
              <div class="w-12 h-12 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-white group-hover:bg-white group-hover:text-indigo-600 transition-all text-xl">
                ?
              </div>
            </div>
            <div class="space-y-3">
              <h2 class="text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight">Stranger Things</h2>
              <p class="text-slate-200 text-base">�� 3 �� �� �� 4 �� �� ��ɣ�ò��ԡ�</p>

              <div class="space-y-3 pt-3">
                <div class="flex justify-between text-sm font-medium text-slate-200">
                  <span>�������ն�</span>
                  <span>12/15 ��</span>
                </div>
                <div class="w-full bg-slate-700/50 rounded-full h-2.5 overflow-hidden backdrop-blur-sm">
                  <div class="bg-gradient-to-r from-indigo-500 to-purple-500 h-2.5 rounded-full shadow-[0_0_10px_rgba(167,139,250,0.5)]" style="width: 80%"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Daily Stats Card -->
        <div class="bg-white/80 backdrop-blur-sm rounded-3xl border border-white p-6 shadow-sm hover:shadow-lg hover:shadow-orange-500/10 transition-all group">
          <div class="flex justify-between items-start mb-4">
            <div class="w-12 h-12 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center text-2xl shadow-inner">
              ??
            </div>
            <span class="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full">����</span>
          </div>
          <div class="text-4xl font-black text-slate-900">{{ stats.wordsToday }}</div>
          <div class="text-slate-500 text-sm mt-2 group-hover:text-orange-600 transition-colors">�����յ���</div>
        </div>

        <!-- AI Assistant Quick Access -->
        <div class="bg-gradient-to-br from-violet-600 to-fuchsia-600 rounded-3xl p-6 shadow-lg shadow-violet-500/30 text-white relative overflow-hidden group cursor-pointer min-h-[200px]" @click="$router.push('/ai-assistant')">
          <div class="absolute -right-4 -top-4 w-24 h-24 bg-white/20 rounded-full blur-xl group-hover:bg-white/30 transition-all"></div>
          <div class="relative z-10 h-full flex flex-col justify-between">
            <div class="space-y-2">
              <div class="flex items-center gap-2 mb-2">
                <svg class="w-5 h-5 text-violet-200 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                </svg>
                <span class="text-sm font-bold text-violet-100 uppercase tracking-wide">AI ����</span>
              </div>
              <h3 class="text-xl font-bold leading-snug">�������<br />���ӣ�</h3>
            </div>
            <button class="bg-white text-violet-600 px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg hover:scale-105 transition-transform w-fit mt-4">
              �� AI ��
            </button>
          </div>
        </div>

        <!-- Recent Collection -->
        <div class="lg:col-span-2 bg-white/80 backdrop-blur-sm rounded-3xl border border-white p-6 shadow-sm min-h-[180px]">
          <div class="flex justify-between items-center mb-6">
            <h3 class="font-bold text-slate-900 text-xl">����ղ�</h3>
            <div class="flex gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-red-500"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-yellow-500"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-green-500"></span>
            </div>
          </div>

          <div class="space-y-4">
            <div
              v-for="(word, index) in recentWords"
              :key="word.id"
              class="flex items-start gap-4 p-4 rounded-2xl hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-all group cursor-pointer"
            >
              <div :class="[
                'w-14 h-14 rounded-xl flex flex-col items-center justify-center font-bold text-sm flex-shrink-0',
                index === 0 ? 'bg-blue-50 text-blue-600 border border-blue-100' : 'bg-green-50 text-green-600 border border-green-100'
              ]">
                <span class="text-[10px] uppercase opacity-50 leading-tight">Vol.</span>
                <span class="text-lg">{{ String(index + 1).padStart(2, '0') }}</span>
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between gap-3 mb-1">
                  <div :class="[
                    'font-bold text-xl transition-colors leading-tight',
                    index === 0 ? 'text-slate-900 group-hover:text-blue-600' : 'text-slate-900 group-hover:text-green-600'
                  ]">{{ word.word }}</div>
                  <span :class="[
                    'px-3 py-1 rounded-full text-xs font-bold flex-shrink-0',
                    index === 0 ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                  ]">{{ word.source }}</span>
                </div>
                <div class="text-sm text-slate-500 mt-1">{{ word.translation }}</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Weekly Activity Chart -->
        <div class="lg:col-span-2 bg-white/80 backdrop-blur-sm rounded-3xl border border-white p-6 shadow-sm min-h-[280px]">
          <div class="mb-6">
            <h3 class="font-bold text-slate-900 text-xl">ÿ�ܻ�Ծ��</h3>
            <p class="text-sm text-slate-400 mt-1">������ѧϰ {{ stats.weeklyMinutes }} ����</p>
          </div>
          <div class="flex items-end justify-between gap-4 h-48">
            <div v-for="(day, index) in weeklyActivity" :key="index" class="flex-1 flex flex-col items-center justify-end gap-3">
              <div class="w-full rounded-t-xl relative transition-all hover:opacity-80" :style="{ height: day.height }" :class="day.active ? (index === 1 ? 'bg-violet-500' : (index === 3 ? 'bg-gradient-to-t from-pink-500 to-orange-400' : 'bg-slate-200')) : 'bg-slate-200'">
              </div>
              <span class="text-sm text-slate-500 font-medium">{{ day.label }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { wordApi, learningApi } from '@/api'

const authStore = useAuthStore()

const stats = ref({
  wordsToday: 24,
  weeklyMinutes: 420,
  totalWords: 0,
  mastered: 0
})

const recentWords = ref([
  {
    id: 1,
    word: 'closure',
    translation: 'closure�����ķ���',
    source: 'Unknown'
  },
  {
    id: 2,
    word: 'hence',
    translation: '���',
    source: 'Unknown'
  }
])

const weeklyActivity = ref([
  { label: 'M', height: '40%', active: false },
  { label: 'T', height: '60%', active: true },
  { label: 'W', height: '30%', active: false },
  { label: 'T', height: '80%', active: true },
  { label: 'F', height: '50%', active: false },
  { label: 'S', height: '70%', active: false },
  { label: 'S', height: '45%', active: false },
])

// Load real data
onMounted(async () => {
  try {
    // Load learning stats
    const learningResponse = await learningApi.getPlan()
    if (learningResponse.code === 200) {
      stats.value.totalWords = learningResponse.data.total_words
      stats.value.mastered = learningResponse.data.mastered
    }

    // Load recent words
    const wordsResponse = await wordApi.getList({ page: 1, page_size: 5, order_by: 'time' })
    if (wordsResponse.code === 200 && wordsResponse.data.items.length > 0) {
      recentWords.value = wordsResponse.data.items.slice(0, 2).map((word) => ({
        id: word.id,
        word: word.word,
        translation: word.translation,
        source: word.tv_shows?.[0] || 'Unknown'
      }))
    }
  } catch (error) {
    console.error('Failed to load dashboard data:', error)
  }
})
</script>

<style scoped>
/* Additional styles if needed */
</style>
