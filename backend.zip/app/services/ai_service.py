"""
AI 服务模块
使用 iFlow API 提供智能助手功能
"""
import json
from openai import OpenAI
import os


class AIService:
    """AI 服务类"""

    def __init__(self):
        """初始化 AI 服务"""
        # 从配置文件加载
        config_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'ai_config.json')

        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                self.api_key = config.get('api_key', '')
                self.base_url = config.get('base_url', 'https://apis.iflow.cn/v1')
                self.model = config.get('model', 'Qwen3-Coder-Plus')
        except FileNotFoundError:
            # 如果配置文件不存在，使用默认配置
            self.api_key = "sk-765f4fdc95a1fcc249b3008091825e42"
            self.base_url = "https://apis.iflow.cn/v1"
            self.model = "Qwen3-Coder-Plus"

        # 初始化 OpenAI 客户端
        self.client = OpenAI(
            base_url=self.base_url,
            api_key=self.api_key,
        )

    def generate_word_usage(self, word: str, tv_show: str = None) -> dict:
        """
        生成单词的详细用法解析

        Args:
            word: 要查询的单词
            tv_show: 剧集名称（可选）

        Returns:
            dict: 包含用法解析的字典
        """
        # 构建 prompt
        if tv_show:
            prompt = f"""请详细分析单词 "{word}" 在美剧《{tv_show}》或类似剧集中的用法。

要求：
1. 开头用一句话概括这个单词的核心含义和使用场景
2. 列出至少4个不同场景下的用法，每个用法包括：
   - 场景标题（如：Ted 的经典台词中使用）
   - 场景描述
   - 英文例句（尽量贴近剧集风格）
   - 中文翻译
   - 用法解释
3. 在最后添加一个"小结"部分，总结核心用法和注意事项
4. 提供2-3个相关延伸问题

请用中文回答，但例句要用英文。格式要清晰，易于理解。"""
        else:
            prompt = f"""请详细分析单词 "{word}" 的常见用法。

要求：
1. 开头用一句话概括这个单词的核心含义和使用场景
2. 列出至少4个不同场景下的用法，每个用法包括：
   - 场景标题（如：日常对话中、正式场合中等）
   - 场景描述
   - 英文例句
   - 中文翻译
   - 用法解释
3. 在最后添加一个"小结"部分，总结核心用法和注意事项
4. 提供2-3个相关延伸问题

请用中文回答，但例句要用英文。格式要清晰，易于理解。"""

        try:
            print(f"[AI Service] 开始调用 AI API，单词: {word}, 剧名: {tv_show}")

            # 调用 AI API
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "你是一位专业的英语教学助手，擅长通过美剧场景帮助学生理解和记忆单词用法。你的解释要生动、具体、易于理解。"
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=2000
            )

            # 获取回复
            content = response.choices[0].message.content

            print(f"[AI Service] AI API 调用成功")
            print(f"[AI Service] 返回内容长度: {len(content) if content else 0}")
            print(f"[AI Service] 返回内容类型: {type(content)}")
            if content:
                print(f"[AI Service] 内容预览: {content[:100]}...")
            else:
                print(f"[AI Service] ⚠️ 警告：AI 返回的 content 为空或 None")
                print(f"[AI Service] 完整响应: {response}")

            return {
                "success": True,
                "word": word,
                "tv_show": tv_show,
                "content": content if content else "",
                "model": self.model
            }

        except Exception as e:
            print(f"[AI Service] ❌ AI API 调用失败: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "message": "AI 服务调用失败"
            }

    def generate_examples(self, word: str, count: int = 5) -> dict:
        """
        生成单词的例句

        Args:
            word: 要生成例句的单词
            count: 例句数量

        Returns:
            dict: 包含例句列表的字典
        """
        prompt = f"""请为单词 "{word}" 生成 {count} 个例句。

要求：
1. 例句要涵盖不同难度（从简单到复杂）
2. 包含不同使用场景（日常对话、正式场合、俚语等）
3. 每个例句都要提供中文翻译
4. 简要说明每个例句的使用场景

请用 JSON 格式返回，格式如下：
{{
    "examples": [
        {{
            "sentence": "英文例句",
            "translation": "中文翻译",
            "scenario": "使用场景",
            "level": "难度等级（beginner/intermediate/advanced）"
        }}
    ]
}}"""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "你是一位英语例句生成专家。请严格按照 JSON 格式返回结果。"
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.8,
                max_tokens=1500
            )

            content = response.choices[0].message.content

            # 尝试解析 JSON
            try:
                # 提取 JSON 部分（可能包含 ```json 标记）
                if "```json" in content:
                    content = content.split("```json")[1].split("```")[0].strip()
                elif "```" in content:
                    content = content.split("```")[1].split("```")[0].strip()

                result = json.loads(content)
                result["success"] = True
                result["word"] = word
                return result
            except json.JSONDecodeError:
                # 如果解析失败，返回原文
                return {
                    "success": True,
                    "word": word,
                    "content": content,
                    "note": "返回格式不是标准 JSON"
                }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "AI 服务调用失败"
            }

    def explain_difference(self, words: list) -> dict:
        """
        解释多个近义词的用法差异

        Args:
            words: 近义词列表

        Returns:
            dict: 包含差异解释的字典
        """
        words_str = "、".join(words)
        prompt = f"""请详细解释以下近义词的用法差异：{words_str}

要求：
1. 首先概括性说明这些词的共同点
2. 详细解释每个词的：
   - 核心含义
   - 使用场景
   - 语气/正式程度
   - 常见搭配
3. 为每个词提供 2-3 个例句（英文+中文翻译）
4. 总结使用建议

请用中文解释，但例句用英文。"""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "你是一位英语词汇辨析专家，擅长解释近义词之间的细微差别。"
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=2000
            )

            content = response.choices[0].message.content

            return {
                "success": True,
                "words": words,
                "content": content,
                "model": self.model
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "AI 服务调用失败"
            }

    def generate_memory_tips(self, word: str) -> dict:
        """
        生成单词记忆口诀

        Args:
            word: 要生成记忆口诀的单词

        Returns:
            dict: 包含记忆技巧的字典
        """
        prompt = f"""请为单词 "{word}" 提供创意记忆方法。

要求：
1. 词根词缀分析（如果适用）
2. 联想记忆法（通过发音、形状等联想）
3. 谐音记忆（中文谐音）
4. 场景记忆（通过具体场景记忆）
5. 顺口溜或口诀

请提供至少 3 种不同的记忆方法，越有创意越好！"""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "你是一位创意英语记忆法专家，擅长用有趣的方法帮助学生记忆单词。"
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.9,
                max_tokens=1000
            )

            content = response.choices[0].message.content

            return {
                "success": True,
                "word": word,
                "content": content,
                "model": self.model
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "AI 服务调用失败"
            }


# 创建全局 AI 服务实例
ai_service = AIService()
