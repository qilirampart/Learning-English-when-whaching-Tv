<template>
  <div class="w-full min-h-screen flex justify-center">
    <div class="w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-8 ai-assistant-container">
    <el-card class="header-card">
      <div class="header-content">
        <h2>🤖 AI 智能助手</h2>
        <p>输入单词和剧名，AI 帮你深度解析用法</p>
      </div>
    </el-card>

    <!-- 搜索输入区域 -->
    <el-card class="search-card">
      <el-form :model="searchForm" label-width="80px">
        <el-form-item label="单词">
          <el-input
            v-model="searchForm.word"
            placeholder="请输入要查询的单词，如：bastard"
            clearable
            @keyup.enter="handleSearch"
          >
            <template #append>
              <el-button
                type="primary"
                :icon="Search"
                :loading="loading"
                @click="handleSearch"
              >
                生成解析
              </el-button>
            </template>
          </el-input>
        </el-form-item>

        <el-form-item label="剧名">
          <el-input
            v-model="searchForm.tvShow"
            placeholder="选填：如《老友记》《生活大爆炸》等"
            clearable
            @keyup.enter="handleSearch"
          />
          <div class="tv-show-tags">
            <el-tag
              v-for="show in popularTvShows"
              :key="show.en"
              class="tv-tag"
              @click="selectTvShow(show)"
              style="cursor: pointer;"
            >
              {{ show.zh }}
            </el-tag>
          </div>
        </el-form-item>
      </el-form>

      <!-- 快捷操作按钮 -->
      <div class="quick-actions">
        <el-button-group>
          <el-button @click="showExamples">生成例句</el-button>
          <el-button @click="showMemoryTips">记忆口诀</el-button>
        </el-button-group>
      </div>

      <!-- 进度条 -->
      <div v-if="loadingProgress > 0" class="loading-progress">
        <div class="progress-text">{{ loadingText }}</div>
        <el-progress
          :percentage="Math.floor(loadingProgress)"
          :status="loadingProgress === 100 ? 'success' : undefined"
          :stroke-width="8"
        />
      </div>
    </el-card>

    <!-- AI 生成结果展示区域 -->
    <el-card v-if="result" class="result-card" v-loading="loading">
      <template #header>
        <div class="result-header">
          <span class="result-title">
            <el-icon><ChatDotRound /></el-icon>
            AI 为您生成的内容
          </span>
          <el-button
            type="primary"
            size="small"
            :icon="CopyDocument"
            @click="copyResult"
          >
            复制
          </el-button>
        </div>
      </template>

      <!-- Markdown 内容渲染 -->
      <div class="result-content" v-html="renderedContent"></div>

      <!-- 相关操作 -->
      <div class="result-actions">
        <el-button
          type="success"
          :icon="Check"
          @click="saveToWordList"
        >
          保存到单词本
        </el-button>
        <el-button
          :icon="RefreshRight"
          @click="handleSearch"
        >
          重新生成
        </el-button>
      </div>
    </el-card>

    <!-- 空状态提示 -->
    <el-empty
      v-if="!result && !loading"
      description="输入单词开始使用 AI 智能助手"
      :image-size="200"
    />

    <!-- 功能介绍卡片 -->
    <el-row v-if="!result && !loading" :gutter="20" class="feature-cards">
      <el-col :span="8">
        <el-card shadow="hover" class="feature-card">
          <div class="feature-icon">📝</div>
          <h3>用法解析</h3>
          <p>深度分析单词在不同场景下的用法</p>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover" class="feature-card">
          <div class="feature-icon">💡</div>
          <h3>例句生成</h3>
          <p>生成多个不同难度的实用例句</p>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover" class="feature-card">
          <div class="feature-icon">🧠</div>
          <h3>记忆技巧</h3>
          <p>提供创意记忆方法，快速记住单词</p>
        </el-card>
      </el-col>
    </el-row>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, ChatDotRound, CopyDocument, Check, RefreshRight } from '@element-plus/icons-vue'
import { marked } from 'marked'
import api from '@/api'

// 搜索表单
const searchForm = ref({
  word: '',
  tvShow: ''
})

// 热门剧名列表（中英文映射）
const popularTvShows = ref([
  { zh: '老友记', en: 'Friends' },
  { zh: '生活大爆炸', en: 'The Big Bang Theory' },
  { zh: '老爸老妈浪漫史', en: 'How I Met Your Mother' },
  { zh: '权力的游戏', en: 'Game of Thrones' },
  { zh: '绝命毒师', en: 'Breaking Bad' },
  { zh: '神探夏洛克', en: 'Sherlock' },
  { zh: '纸牌屋', en: 'House of Cards' },
  { zh: '金装律师', en: 'Suits' }
])

// 加载状态
const loading = ref(false)

// AI 生成结果
const result = ref(null)

// 选择剧名
const selectTvShow = (show) => {
  searchForm.value.tvShow = show.en
}

// 进度条相关
const loadingProgress = ref(0)
const loadingText = ref('')
let progressTimer = null

// 启动进度条
const startProgress = (text = 'AI 正在生成中') => {
  loadingProgress.value = 0
  loadingText.value = text

  // 清除之前的定时器
  if (progressTimer) {
    clearInterval(progressTimer)
  }

  // 模拟进度增长
  progressTimer = setInterval(() => {
    if (loadingProgress.value < 90) {
      // 前90%：每200ms增加3-8%
      const increment = Math.random() * 5 + 3
      loadingProgress.value = Math.min(90, loadingProgress.value + increment)
    }
  }, 200)
}

// 完成进度条
const finishProgress = () => {
  loadingProgress.value = 100

  if (progressTimer) {
    clearInterval(progressTimer)
    progressTimer = null
  }

  // 1秒后隐藏进度条
  setTimeout(() => {
    loadingProgress.value = 0
    loadingText.value = ''
  }, 1000)
}

// 渲染 Markdown 内容
const renderedContent = computed(() => {
  if (!result.value || !result.value.content) return ''

  // 使用 marked 解析 Markdown
  return marked.parse(result.value.content)
})

// 处理搜索
const handleSearch = async () => {
  if (!searchForm.value.word.trim()) {
    ElMessage.warning('请输入要查询的单词')
    return
  }

  loading.value = true
  result.value = null
  startProgress('AI 正在分析单词用法，请稍候...')

  try {
    const response = await api.post('/api/ai/usage', {
      word: searchForm.value.word.trim(),
      tv_show: searchForm.value.tvShow.trim() || null
    })

    if (response.data.code === 200) {
      const aiData = response.data.data
      console.log('AI 返回数据:', aiData) // 调试日志

      // 验证返回的数据完整性
      if (!aiData || !aiData.content || aiData.content.trim().length === 0) {
        console.error('AI 返回数据不完整:', aiData)
        ElMessage.error('AI 生成的内容为空，请重试')
        finishProgress()
        return
      }

      result.value = aiData
      finishProgress()
      ElMessage.success('生成成功！')
    } else {
      finishProgress()
      ElMessage.error(response.data.message || '生成失败')
    }
  } catch (error) {
    console.error('AI 调用失败:', error)
    finishProgress()
    ElMessage.error('服务调用失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

// 显示例句
const showExamples = async () => {
  if (!searchForm.value.word.trim()) {
    ElMessage.warning('请先输入单词')
    return
  }

  loading.value = true
  result.value = null
  startProgress('AI 正在生成例句，请稍候...')

  try {
    const response = await api.post('/api/ai/examples', {
      word: searchForm.value.word.trim(),
      count: 5
    })

    if (response.data.code === 200) {
      result.value = response.data.data
      finishProgress()
      ElMessage.success('例句生成成功！')
    } else {
      finishProgress()
      ElMessage.error(response.data.message || '生成失败')
    }
  } catch (error) {
    console.error('AI 调用失败:', error)
    finishProgress()
    ElMessage.error('服务调用失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

// 显示记忆口诀
const showMemoryTips = async () => {
  if (!searchForm.value.word.trim()) {
    ElMessage.warning('请先输入单词')
    return
  }

  loading.value = true
  result.value = null
  startProgress('AI 正在生成记忆技巧，请稍候...')

  try {
    const response = await api.post('/api/ai/memory-tips', {
      word: searchForm.value.word.trim()
    })

    if (response.data.code === 200) {
      result.value = response.data.data
      finishProgress()
      ElMessage.success('记忆技巧生成成功！')
    } else {
      finishProgress()
      ElMessage.error(response.data.message || '生成失败')
    }
  } catch (error) {
    console.error('AI 调用失败:', error)
    finishProgress()
    ElMessage.error('服务调用失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

// 复制结果
const copyResult = () => {
  if (!result.value || !result.value.content) return

  navigator.clipboard.writeText(result.value.content)
    .then(() => {
      ElMessage.success('已复制到剪贴板')
    })
    .catch(() => {
      ElMessage.error('复制失败')
    })
}

// 从 AI 内容中提取例句（带中文翻译）
const extractExamples = (content) => {
  if (!content) return []

  const examples = []
  const lines = content.split('\n')

  let currentEnglish = null
  let currentChinese = null

  // 查找英文例句和对应的中文翻译
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]

    // 匹配英文例句行
    if (line.includes('英文例句') || line.includes('**英文')) {
      const match = line.match(/"([^"]+)"/)
      if (match && match[1]) {
        const sentence = match[1].trim()
        const englishChars = (sentence.match(/[a-zA-Z]/g) || []).length

        // 确保是英文句子
        if (englishChars > 10) {
          currentEnglish = sentence
        }
      }
    }

    // 匹配中文翻译行
    else if (currentEnglish && (line.includes('中文翻译') || line.includes('**中文'))) {
      const match = line.match(/"([^"]+)"/)
      if (match && match[1]) {
        currentChinese = match[1].trim()

        // 保存英文和中文配对
        examples.push({
          english: currentEnglish,
          chinese: currentChinese
        })

        currentEnglish = null
        currentChinese = null

        if (examples.length >= 2) break // 只取前两个
      }
    }
  }

  return examples
}

// 保存状态（防止重复点击）
const saving = ref(false)

// 保存到单词本
const saveToWordList = async () => {
  // 防止重复点击
  if (saving.value) {
    console.log('保存中，请勿重复点击')
    return
  }

  if (!result.value || !result.value.word) {
    ElMessage.warning('没有可保存的单词')
    return
  }

  const word = result.value.word
  const tvShow = result.value.tv_show || searchForm.value.tvShow.trim() || ''

  // 从 AI 生成的内容中提取前两个例句
  const examples = extractExamples(result.value.content)

  if (examples.length === 0) {
    ElMessage.warning('未找到合适的例句')
    return
  }

  // 格式化例句文本（与图片格式一致）
  let contextNote = 'AI 助手生成的例句：  '
  examples.forEach((example, index) => {
    contextNote += `${index + 1}. 英文例句："${example.english}"  中文翻译："${example.chinese}"  `
  })

  saving.value = true

  try {
    // 调用查询 API 保存单词
    const response = await api.post('/api/words/query', {
      word: word,
      tv_show: tvShow,
      context_note: contextNote.trim()
    })

    if (response.data.code === 200) {
      ElMessage.success({
        message: `单词"${word}"已保存到单词本！`,
        duration: 3000
      })
    } else {
      ElMessage.error(response.data.message || '保存失败')
    }
  } catch (error) {
    console.error('保存失败:', error)
    if (error.response && error.response.status === 500) {
      ElMessage.error('服务器错误，请检查单词是否已存在或稍后重试')
    } else {
      ElMessage.error('保存失败，请重试')
    }
  } finally {
    // 延迟解锁，防止快速重复点击
    setTimeout(() => {
      saving.value = false
    }, 1000)
  }
}
</script>

<style scoped lang="scss">
.ai-assistant-container {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.header-card {
  margin-bottom: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;

  :deep(.el-card__body) {
    padding: 30px;
  }

  .header-content {
    text-align: center;
    color: white;

    h2 {
      margin: 0 0 10px 0;
      font-size: 32px;
      font-weight: bold;
    }

    p {
      margin: 0;
      font-size: 16px;
      opacity: 0.9;
    }
  }
}

.search-card {
  margin-bottom: 20px;

  :deep(.el-form-item) {
    margin-bottom: 18px;
  }

  .tv-show-tags {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 8px;

    .tv-tag {
      transition: all 0.3s ease;

      &:hover {
        transform: translateY(-2px);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      }
    }
  }

  .quick-actions {
    text-align: center;
    padding-top: 10px;
  }

  .loading-progress {
    margin-top: 20px;
    padding: 16px;
    background: #f5f7fa;
    border-radius: 8px;

    .progress-text {
      margin-bottom: 12px;
      text-align: center;
      font-size: 14px;
      color: #606266;
      font-weight: 500;
    }
  }
}

.result-card {
  margin-bottom: 20px;

  .result-header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .result-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 18px;
      font-weight: bold;
      color: #303133;
    }
  }

  .result-content {
    padding: 20px 0;
    line-height: 1.8;
    font-size: 15px;
    color: #606266;

    :deep(h1), :deep(h2), :deep(h3), :deep(h4) {
      margin-top: 24px;
      margin-bottom: 16px;
      font-weight: 600;
      color: #303133;
    }

    :deep(h1) {
      font-size: 28px;
      border-bottom: 2px solid #dcdfe6;
      padding-bottom: 10px;
    }

    :deep(h2) {
      font-size: 24px;
    }

    :deep(h3) {
      font-size: 20px;
    }

    :deep(p) {
      margin-bottom: 16px;
    }

    :deep(ul), :deep(ol) {
      margin-bottom: 16px;
      padding-left: 30px;
    }

    :deep(li) {
      margin-bottom: 8px;
    }

    :deep(code) {
      background-color: #f5f7fa;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      color: #e03997;
    }

    :deep(pre) {
      background-color: #f5f7fa;
      padding: 16px;
      border-radius: 8px;
      overflow-x: auto;
      margin-bottom: 16px;

      code {
        background-color: transparent;
        padding: 0;
        color: #303133;
      }
    }

    :deep(blockquote) {
      border-left: 4px solid #409eff;
      padding-left: 16px;
      margin: 16px 0;
      color: #909399;
      font-style: italic;
    }

    :deep(strong) {
      font-weight: 600;
      color: #303133;
    }

    :deep(em) {
      font-style: italic;
      color: #606266;
    }
  }

  .result-actions {
    text-align: center;
    padding-top: 20px;
    border-top: 1px solid #ebeef5;

    .el-button {
      margin: 0 10px;
    }
  }
}

.feature-cards {
  margin-top: 30px;

  .feature-card {
    text-align: center;
    transition: transform 0.3s ease;

    &:hover {
      transform: translateY(-5px);
    }

    .feature-icon {
      font-size: 48px;
      margin-bottom: 16px;
    }

    h3 {
      margin: 0 0 12px 0;
      font-size: 20px;
      color: #303133;
    }

    p {
      margin: 0;
      color: #909399;
      font-size: 14px;
    }
  }
}

// 深色模式适配
html.dark {
  .header-card {
    background: linear-gradient(135deg, #4a5568 0%, #2d3748 100%);
  }

  .search-card {
    .loading-progress {
      background: #30303a;

      .progress-text {
        color: #c9d1d9;
      }
    }
  }

  .result-card {
    .result-header .result-title {
      color: #e5eaf3;
    }

    .result-content {
      color: #c9d1d9;

      :deep(h1), :deep(h2), :deep(h3), :deep(h4) {
        color: #e5eaf3;
      }

      :deep(code) {
        background-color: #30303a;
        color: #ff79c6;
      }

      :deep(pre) {
        background-color: #30303a;

        code {
          color: #e5eaf3;
        }
      }

      :deep(strong) {
        color: #e5eaf3;
      }
    }
  }

  .feature-card {
    h3 {
      color: #e5eaf3;
    }

    p {
      color: #8b949e;
    }
  }
}
</style>
