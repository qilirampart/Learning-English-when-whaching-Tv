/**
 * 单词发音工具 - 基于 Web Speech API
 * 支持发音播放、速度调节、口音切换
 */

import { ref } from 'vue'
import { ElMessage } from 'element-plus'

// 发音配置选项
const SPEECH_CONFIG = {
  // 语言和口音
  accents: {
    US: 'en-US', // 美式英语
    GB: 'en-GB', // 英式英语
    AU: 'en-AU', // 澳式英语
  },
  // 播放速度
  rates: {
    slow: 0.7,    // 慢速
    normal: 1.0,  // 正常速度
    fast: 1.3,    // 快速
  },
  // 音量
  volume: 1.0, // 0-1
}

/**
 * 发音功能组合式函数
 */
export function useSpeech() {
  // 检查浏览器支持
  const isSupported = ref('speechSynthesis' in window)

  // 当前播放状态
  const isSpeaking = ref(false)

  // 当前配置
  const currentAccent = ref(localStorage.getItem('speech_accent') || 'US')
  const currentRate = ref(localStorage.getItem('speech_rate') || 'normal')

  /**
   * 播放单词发音
   * @param {string} word - 要发音的单词
   * @param {object} options - 配置选项
   */
  const speak = (word, options = {}) => {
    // 检查浏览器支持
    if (!isSupported.value) {
      ElMessage.warning('您的浏览器不支持语音播放功能')
      return
    }

    // 如果正在播放，先停止
    if (isSpeaking.value) {
      window.speechSynthesis.cancel()
    }

    // 合并配置
    const config = {
      accent: options.accent || currentAccent.value,
      rate: options.rate || currentRate.value,
      ...options
    }

    // 创建语音合成实例
    const utterance = new SpeechSynthesisUtterance(word)

    // 设置语言（口音）
    utterance.lang = SPEECH_CONFIG.accents[config.accent] || SPEECH_CONFIG.accents.US

    // 设置播放速度
    utterance.rate = SPEECH_CONFIG.rates[config.rate] || SPEECH_CONFIG.rates.normal

    // 设置音量
    utterance.volume = config.volume || SPEECH_CONFIG.volume

    // 设置音高（可选）
    utterance.pitch = config.pitch || 1.0

    // 事件监听
    utterance.onstart = () => {
      isSpeaking.value = true
    }

    utterance.onend = () => {
      isSpeaking.value = false
    }

    utterance.onerror = (event) => {
      isSpeaking.value = false
      console.error('语音播放错误:', event)
      ElMessage.error('发音播放失败，请重试')
    }

    // 播放
    window.speechSynthesis.speak(utterance)
  }

  /**
   * 停止播放
   */
  const stop = () => {
    if (isSupported.value && isSpeaking.value) {
      window.speechSynthesis.cancel()
      isSpeaking.value = false
    }
  }

  /**
   * 暂停播放
   */
  const pause = () => {
    if (isSupported.value && isSpeaking.value) {
      window.speechSynthesis.pause()
    }
  }

  /**
   * 恢复播放
   */
  const resume = () => {
    if (isSupported.value) {
      window.speechSynthesis.resume()
    }
  }

  /**
   * 设置口音
   * @param {string} accent - 'US' | 'GB' | 'AU'
   */
  const setAccent = (accent) => {
    if (SPEECH_CONFIG.accents[accent]) {
      currentAccent.value = accent
      localStorage.setItem('speech_accent', accent)
    }
  }

  /**
   * 设置播放速度
   * @param {string} rate - 'slow' | 'normal' | 'fast'
   */
  const setRate = (rate) => {
    if (SPEECH_CONFIG.rates[rate]) {
      currentRate.value = rate
      localStorage.setItem('speech_rate', rate)
    }
  }

  /**
   * 获取可用的语音列表
   */
  const getVoices = () => {
    if (!isSupported.value) return []
    return window.speechSynthesis.getVoices()
  }

  /**
   * 快捷方法：慢速播放
   */
  const speakSlow = (word) => {
    speak(word, { rate: 'slow' })
  }

  /**
   * 快捷方法：美音播放
   */
  const speakUS = (word) => {
    speak(word, { accent: 'US' })
  }

  /**
   * 快捷方法：英音播放
   */
  const speakGB = (word) => {
    speak(word, { accent: 'GB' })
  }

  return {
    // 状态
    isSupported,
    isSpeaking,
    currentAccent,
    currentRate,

    // 方法
    speak,
    stop,
    pause,
    resume,
    setAccent,
    setRate,
    getVoices,

    // 快捷方法
    speakSlow,
    speakUS,
    speakGB,

    // 配置
    SPEECH_CONFIG,
  }
}

/**
 * 简化版：直接播放单词
 * 用于快速集成到现有组件
 */
export function playWord(word, options = {}) {
  const { speak } = useSpeech()
  speak(word, options)
}

export default useSpeech
